<!--Hope Page-->
<h1>Welcome to My Life Manager</h1>
<nav>
  <a href="/budgeting">💰 Budgeting</a>
  <a href="/recipes">🍲 Recipes</a>
  <a href="/outfits">👚 Outfits</a>
</nav>